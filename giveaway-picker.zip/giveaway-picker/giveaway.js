/**
 * Giveaway Picker - Loading Spinner, Countdown & Celebration Modal
 * Reads winner configuration from winner/person.js and profile image from winner/profile.png
 */

// Define global trigger immediately so inline onclick="uckls(1);" is never undefined
window.uckls = function (step) {
  if (typeof window.triggerGiveawayFlow === 'function') {
    window.triggerGiveawayFlow();
  }
};

(function () {
  'use strict';

  // Format and normalize the target URL
  function normalizeUrl(rawUrl) {
    if (!rawUrl) return 'https://www.google.com';
    let url = String(rawUrl).trim();
    if (!/^https?:\/\//i.test(url)) {
      url = url.replace(/^w{3,4}\./i, 'www.');
      url = 'https://' + url;
    }
    return url;
  }

  // Get winner data (from winner/person.js, fallback if not loaded)
  function getWinner() {
    const defaultWinner = {
      name: 'Badea Adrian',
      url: 'https://www.google.com'
    };

    let data = null;
    try {
      if (typeof winner !== 'undefined' && winner) {
        data = winner;
      }
    } catch (e) {}

    if (!data && typeof window !== 'undefined' && window.winner) {
      data = window.winner;
    }

    if (data && typeof data === 'object') {
      return {
        name: data.name || defaultWinner.name,
        url: normalizeUrl(data.url || defaultWinner.url)
      };
    }
    return defaultWinner;
  }

  // Simulated candidate names for ticker
  const CANDIDATES = [
    '@alexandra.m',
    '@marian_popa',
    '@elena_dragoi',
    '@cristian.radu',
    '@andreea_v',
    '@dan_ionescu',
    '@gabriela.s',
    '@bogdan_stan',
    '@ioana.stefan',
    '@badeaadrian'
  ];

  let modalEl = null;
  let confettiCanvas = null;
  let confettiAnimId = null;
  let countdownTimer = null;
  let tickerInterval = null;
  let isFlowRunning = false;

  // Build and inject Modal Elements into DOM
  function ensureModalDOM() {
    if (document.getElementById('gw-modal-root')) {
      refreshWinnerInfo();
      return;
    }

    const winner = getWinner();
    const profileImgPath = 'winner/profile.png';

    const root = document.createElement('div');
    root.id = 'gw-modal-root';
    root.innerHTML = `
      <canvas id="gw-confetti-canvas"></canvas>
      <div class="gw-overlay" id="gw-overlay" aria-hidden="true">
        <div class="gw-modal-container" role="dialog" aria-modal="true" aria-labelledby="gw-dialog-title">
          <button class="gw-close-btn" id="gw-close-btn" aria-label="Close modal">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>

          <!-- PHASE 1: COUNTDOWN -->
          <div class="gw-countdown-view" id="gw-countdown-view">
            <div class="gw-cd-badge">
              <span class="gw-cd-badge-dot"></span>
              Live Random Draw
            </div>

            <div class="gw-timer-wrap">
              <svg class="gw-timer-svg" viewBox="0 0 140 140">
                <circle class="gw-timer-bg" cx="70" cy="70" r="60"></circle>
                <circle class="gw-timer-progress" id="gw-timer-progress" cx="70" cy="70" r="60"></circle>
              </svg>
              <div class="gw-timer-number" id="gw-timer-num">5</div>
            </div>

            <h3 class="gw-cd-title" id="gw-dialog-title">Selecting Lucky Winner...</h3>
            <p class="gw-cd-subtitle">Analyzing entries and picking a fair, verified comment winner</p>

            <div class="gw-ticker">
              <span>Scanning:</span>
              <span class="gw-ticker-name" id="gw-ticker-name">@scanning_entries...</span>
            </div>
          </div>

          <!-- PHASE 2: WINNER CELEBRATION -->
          <div class="gw-winner-view" id="gw-winner-view">
            <div class="gw-ribbon-badge">
              <svg class="gw-badge-crown" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z"/>
              </svg>
              <span class="gw-badge-text">WINNER</span>
            </div>

            <!-- Profile Picture (No Link) -->
            <div class="gw-avatar-wrap" id="gw-avatar-wrap">
              <div class="gw-avatar-halo"></div>
              <div class="gw-avatar-img-wrap">
                <img src="${profileImgPath}" alt="${winner.name}" class="gw-avatar-img" id="gw-avatar-img" onerror="this.src='https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80'" />
              </div>
              <div class="gw-verified-pill" title="Verified Winner">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
              </div>
            </div>

            <!-- Winner Name (No Link, No Icon) -->
            <div class="gw-winner-name-wrap">
              <h2 class="gw-winner-name" id="gw-winner-name-text">${winner.name}</h2>
            </div>
            <div class="gw-winner-sub">Selected fairly from all Instagram comments</div>

            <!-- Action Buttons -->
            <div class="gw-actions">
              <a href="${winner.url}" target="_blank" rel="noopener noreferrer" class="gw-primary-btn" id="gw-cta-btn">
                <span>Visit Profile</span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                  <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
              </a>
              <button type="button" class="gw-secondary-btn" id="gw-reset-btn">
                Pick Another Winner
              </button>
            </div>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(root);

    modalEl = document.getElementById('gw-overlay');
    confettiCanvas = document.getElementById('gw-confetti-canvas');

    // Attach modal close & reset listeners safely
    const closeBtn = document.getElementById('gw-close-btn');
    if (closeBtn) closeBtn.addEventListener('click', closeModal);

    const resetBtn = document.getElementById('gw-reset-btn');
    if (resetBtn) {
      resetBtn.addEventListener('click', function () {
        closeModal();
        setTimeout(triggerGiveawayFlow, 200);
      });
    }

    if (modalEl) {
      modalEl.addEventListener('click', function (e) {
        if (e.target === modalEl) {
          closeModal();
        }
      });
    }

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && modalEl && modalEl.classList.contains('active')) {
        closeModal();
      }
    });
  }

  // Update DOM with freshest winner details
  function refreshWinnerInfo() {
    const winner = getWinner();
    const nameEl = document.getElementById('gw-winner-name-text');
    const ctaBtn = document.getElementById('gw-cta-btn');
    const avatarImg = document.getElementById('gw-avatar-img');

    if (nameEl) nameEl.textContent = winner.name;
    if (ctaBtn) {
      ctaBtn.href = winner.url;
    }
    if (avatarImg) {
      avatarImg.alt = winner.name;
    }
  }

  // Confetti Animation Canvas
  function launchConfetti() {
    if (!confettiCanvas) return;
    const ctx = confettiCanvas.getContext('2d');
    const width = (confettiCanvas.width = window.innerWidth);
    const height = (confettiCanvas.height = window.innerHeight);

    const colors = ['#3258F6', '#60A5FA', '#FFB800', '#FF3366', '#10B981', '#8B5CF6', '#F97316'];
    const particleCount = 140;
    const particles = [];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: width / 2 + (Math.random() - 0.5) * 80,
        y: height / 2 + (Math.random() - 0.5) * 40,
        vx: (Math.random() - 0.5) * 22,
        vy: -Math.random() * 18 - 8,
        size: Math.random() * 8 + 6,
        color: colors[Math.floor(Math.random() * colors.length)],
        rotation: Math.random() * 360,
        rotationSpeed: (Math.random() - 0.5) * 12,
        tilt: Math.random() * 10,
        tiltSpeed: Math.random() * 0.1 + 0.05,
        opacity: 1,
        shape: Math.random() > 0.3 ? 'rect' : 'circle'
      });
    }

    if (confettiAnimId) cancelAnimationFrame(confettiAnimId);

    const startTime = performance.now();
    const duration = 4500;

    function render(currentTime) {
      const elapsed = currentTime - startTime;
      ctx.clearRect(0, 0, width, height);

      let activeParticles = 0;

      for (let p of particles) {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.45;
        p.vx *= 0.98;
        p.rotation += p.rotationSpeed;
        p.tilt += p.tiltSpeed;

        if (elapsed > 2500) {
          p.opacity = Math.max(0, 1 - (elapsed - 2500) / 2000);
        }

        if (p.y < height + 50 && p.opacity > 0) {
          activeParticles++;
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate((p.rotation * Math.PI) / 180);
          ctx.globalAlpha = p.opacity;
          ctx.fillStyle = p.color;

          if (p.shape === 'circle') {
            ctx.beginPath();
            ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
            ctx.fill();
          } else {
            ctx.fillRect(-p.size / 2, -p.size / 4, p.size, (p.size / 2) * Math.sin(p.tilt));
          }

          ctx.restore();
        }
      }

      if (elapsed < duration && activeParticles > 0) {
        confettiAnimId = requestAnimationFrame(render);
      } else {
        ctx.clearRect(0, 0, width, height);
      }
    }

    confettiAnimId = requestAnimationFrame(render);
  }

  // Start Countdown Sequence (5 -> 1)
  function startCountdown() {
    ensureModalDOM();
    refreshWinnerInfo();

    const countdownView = document.getElementById('gw-countdown-view');
    const winnerView = document.getElementById('gw-winner-view');
    const timerNum = document.getElementById('gw-timer-num');
    const timerProgress = document.getElementById('gw-timer-progress');
    const tickerName = document.getElementById('gw-ticker-name');

    // Show countdown, hide winner view
    if (countdownView) countdownView.style.display = 'flex';
    if (winnerView) winnerView.classList.remove('active');

    // Show modal
    if (modalEl) {
      modalEl.classList.add('active');
      modalEl.setAttribute('aria-hidden', 'false');
    }

    // Set up circular timer progress
    const circumference = 377; // 2 * PI * 60
    if (timerProgress) {
      timerProgress.style.strokeDasharray = `${circumference}`;
      timerProgress.style.strokeDashoffset = '0';
    }

    let count = 5;
    if (timerNum) {
      timerNum.textContent = count;
      timerNum.classList.remove('gw-pop');
      void timerNum.offsetWidth;
      timerNum.classList.add('gw-pop');
    }

    // Candidate ticker animation
    if (tickerInterval) clearInterval(tickerInterval);
    let tickerIdx = 0;
    tickerInterval = setInterval(function () {
      if (tickerName) {
        tickerName.textContent = CANDIDATES[tickerIdx % CANDIDATES.length];
      }
      tickerIdx++;
    }, 90);

    if (countdownTimer) clearInterval(countdownTimer);

    countdownTimer = setInterval(function () {
      count--;

      if (count > 0) {
        if (timerNum) {
          timerNum.textContent = count;
          timerNum.classList.remove('gw-pop');
          void timerNum.offsetWidth;
          timerNum.classList.add('gw-pop');
        }

        if (timerProgress) {
          const progressOffset = circumference * (1 - count / 5);
          timerProgress.style.strokeDashoffset = `${progressOffset}`;
        }
      } else {
        // Countdown reached 0 -> Launch Celebration!
        clearInterval(countdownTimer);
        clearInterval(tickerInterval);

        if (timerProgress) {
          timerProgress.style.strokeDashoffset = `${circumference}`;
        }

        setTimeout(function () {
          if (countdownView) countdownView.style.display = 'none';
          if (winnerView) winnerView.classList.add('active');
          launchConfetti();
          isFlowRunning = false;
        }, 280);
      }
    }, 1000);
  }

  // Close Modal
  function closeModal() {
    if (countdownTimer) clearInterval(countdownTimer);
    if (tickerInterval) clearInterval(tickerInterval);
    if (confettiAnimId) cancelAnimationFrame(confettiAnimId);

    if (confettiCanvas) {
      const ctx = confettiCanvas.getContext('2d');
      ctx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
    }

    if (modalEl) {
      modalEl.classList.remove('active');
      modalEl.setAttribute('aria-hidden', 'true');
    }

    isFlowRunning = false;
  }

  // Trigger Full Flow: Spinner on button (1.8s) -> Countdown (5s) -> Winner Celebration
  function triggerGiveawayFlow() {
    if (isFlowRunning) return;
    isFlowRunning = true;

    // Find the Make Giveaway button
    const btn = document.querySelector('#ynckls1 .gndr') || document.querySelector('.yncklsbtn .gndr');
    const container = document.getElementById('ynckls1') || (btn ? btn.parentElement : null);

    let originalBtnText = 'Make Giveaway';
    if (btn) {
      originalBtnText = btn.innerHTML;
      btn.innerHTML = '<span class="gw-btn-spinner"></span> Loading comments...';
      btn.classList.add('is-loading');
    }

    // Add inline status badge directly UNDER button in its own centered row
    let statusWrap = null;
    if (container) {
      statusWrap = document.createElement('div');
      statusWrap.className = 'gw-inline-loading-wrap';
      statusWrap.id = 'gw-inline-status-wrap';
      statusWrap.innerHTML = `
        <div class="gw-inline-loading">
          <span class="gw-inline-spinner"></span>
          <span>Connecting to Instagram & verifying entries...</span>
        </div>
      `;
      container.appendChild(statusWrap);
    }

    // Spinner runs for ~1.8 seconds, then launches countdown modal
    setTimeout(function () {
      if (btn) {
        btn.innerHTML = originalBtnText;
        btn.classList.remove('is-loading');
      }
      if (statusWrap && statusWrap.parentNode) {
        statusWrap.parentNode.removeChild(statusWrap);
      }

      // Open countdown modal
      startCountdown();
    }, 1800);
  }

  // Expose triggers
  window.triggerGiveawayFlow = triggerGiveawayFlow;
  window.startGiveawayCelebration = startCountdown;
  window.uckls = function (step) {
    if (step === 1 || !step) {
      triggerGiveawayFlow();
    }
  };

  // Bind click listener directly to button on DOM load
  function bindEvents() {
    ensureModalDOM();

    const btn = document.querySelector('#ynckls1 .gndr') || document.querySelector('.yncklsbtn .gndr');
    if (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        triggerGiveawayFlow();
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bindEvents);
  } else {
    bindEvents();
  }
})();
